GrpcExample/
├── Protos/                # .proto 文件目录
├── Controllers/           # gRPC 服务处理器
├── Services/              # 业务逻辑层
├── Repositories/          # 数据访问层
├── Models/                # 数据模型
├── Mappings/              # 数据库与模型的映射
├── appsettings.json       # 配置文件
├── Program.cs             # 应用入口
